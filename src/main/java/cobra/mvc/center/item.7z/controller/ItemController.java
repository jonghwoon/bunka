package cobra.mvc.center.item.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cobra.mvc.center.item.service.board.BoardServiceImpl;

/**
 * Handles requests for the application home page.
 */
@Controller
public class ItemController {

	@Inject
	BoardServiceImpl boardService;
	
	//����ȭ��
    @RequestMapping(value = "/main.item")
    public String main(Model model) {

        return "/item/main";
    }
    
    @RequestMapping(value = "/search.item")
    public String search(HttpServletRequest req, Model model) {
    	
    	return "/item/search";
    }
    
    //�󼼰˻� ������
    @RequestMapping(value = "/advSearch.item")
    public String advSearch(HttpServletRequest req, Model model) {
    	System.out.println("/item/advSearch");
    	
    	return "/item/advSearch";
    }
    
    //�Խ���
    @RequestMapping(value = "/bbs.item")
    public String bbs(HttpServletRequest req, Model model) {
    	System.out.println("/item/bbs");
    	
    	return "/item/bbs";
    }
    
    //�������
    @RequestMapping(value = "/bookList.item")
    public String bookList(HttpServletRequest req, Model model) {
    	System.out.println("/item/bookList");
    	
    	return "/item/bookList";
    }
    
    //�۸��
  	@RequestMapping(value = "/list.item", method = {RequestMethod.GET, RequestMethod.POST})
  	public String list(HttpServletRequest req, Model model) throws Exception {
  		System.out.println("/item/list");
  		
  		return "/item/bbs";
  	}

}