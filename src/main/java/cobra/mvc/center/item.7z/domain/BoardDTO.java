package cobra.mvc.center.item.domain;

public class BoardDTO {

}
