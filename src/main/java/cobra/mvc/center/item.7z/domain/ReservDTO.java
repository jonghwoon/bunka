package cobra.mvc.center.item.domain;

public class ReservDTO {
    
}