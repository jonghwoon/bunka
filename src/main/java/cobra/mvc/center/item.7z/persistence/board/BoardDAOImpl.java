package cobra.mvc.center.item.persistence.board;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cobra.mvc.center.item.domain.BoardDTO;

@Repository
public class BoardDAOImpl implements BoardDAO {

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<BoardDTO> getArticles(Map<String, Object> daoMap) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<BoardDTO> getSearch(Map<String, Object> daoMap) {
		// TODO Auto-generated method stub
		return null;
	}

}
