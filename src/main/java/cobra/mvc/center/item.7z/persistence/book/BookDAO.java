package cobra.mvc.center.item.persistence.book;

public interface BookDAO {

}
