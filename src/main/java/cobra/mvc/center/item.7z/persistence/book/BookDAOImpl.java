package cobra.mvc.center.item.persistence.book;

import org.springframework.stereotype.Repository;

@Repository
public class BookDAOImpl implements BookDAO {

}
