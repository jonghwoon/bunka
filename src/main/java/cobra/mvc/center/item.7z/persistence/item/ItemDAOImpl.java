package cobra.mvc.center.item.persistence.item;

import org.springframework.stereotype.Repository;

@Repository
public class ItemDAOImpl implements ItemDAO {

}
