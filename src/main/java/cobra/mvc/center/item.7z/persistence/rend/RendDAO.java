package cobra.mvc.center.item.persistence.rend;

public interface RendDAO {

}
