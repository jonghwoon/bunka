package cobra.mvc.center.item.persistence.rend;

import org.springframework.stereotype.Repository;

@Repository
public class RendDAOImpl implements RendDAO {

}
