package cobra.mvc.center.item.persistence.reserv;

public interface ReservDAO {

}
