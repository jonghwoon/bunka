package cobra.mvc.center.item.persistence.reserv;

import org.springframework.stereotype.Repository;

@Repository
public class ReservDAOImpl implements ReservDAO {

}
