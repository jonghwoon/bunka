package cobra.mvc.center.item.service.item;

import org.springframework.stereotype.Service;

@Service
public class ItemServiceImpl implements ItemService{

}
