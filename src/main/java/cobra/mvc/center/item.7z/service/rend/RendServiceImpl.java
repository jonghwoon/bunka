package cobra.mvc.center.item.service.rend;

import org.springframework.stereotype.Service;

@Service
public class RendServiceImpl implements RendService {

}
