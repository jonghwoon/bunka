package cobra.mvc.center.item.service.reserv;

import org.springframework.stereotype.Service;

@Service
public class ReservServiceImpl implements ReservService{

}
