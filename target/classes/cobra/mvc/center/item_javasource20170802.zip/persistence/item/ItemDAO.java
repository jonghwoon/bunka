package cobra.mvc.center.item.persistence.item;

public interface ItemDAO {

}
